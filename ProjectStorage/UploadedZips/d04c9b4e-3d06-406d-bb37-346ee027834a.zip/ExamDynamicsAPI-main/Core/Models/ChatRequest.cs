namespace ExamDynamicsAPI.Core.Models
{
    public class ChatRequest
{
    public string Message { get; set; } = string.Empty;
}
}